package DefiningClasses4;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int inputs = Integer.parseInt(scanner.nextLine());
        List<Car> carsInfo = new ArrayList<>();

        for (int i = 0; i < inputs; i++) {
            String[] input = scanner.nextLine().split("\\s+");
            // "{Model}-0 {EngineSpeed}-1 {EnginePower}-2 {CargoWeight}-3 {CargoType}-4
            // {Tire1Pressure}-5 {Tire1Age}-6 {Tire2Pressure}-7 {Tire2Age}-8 {Tire3Pressure}-9 {Tire]’3Age}-10 {Tire4Pressure}-11 {Tire4Age}-12"
            String model = input[0];
            int engineSpeed = Integer.parseInt(input[1]);
            int enginePower = Integer.parseInt(input[2]);
            Engine engine = new Engine(engineSpeed, enginePower);

            int cargoWeight = Integer.parseInt(input[3]);
            String cargoType = input[4];
            Cargo cargo = new Cargo(cargoWeight, cargoType);

            double tire1Pressure = Double.parseDouble(input[5]);
            int tire1Age = Integer.parseInt(input[6]);
            double tire2Pressure = Double.parseDouble(input[7]);
            int tire2Age = Integer.parseInt(input[8]);
            double tire3Pressure = Double.parseDouble(input[9]);
            int tire3Age = Integer.parseInt(input[10]);
            double tire4Pressure = Double.parseDouble(input[11]);
            int tire4Age = Integer.parseInt(input[12]);
            Tires tires = new Tires(tire1Pressure, tire1Age, tire2Pressure, tire2Age,
                    tire3Pressure, tire3Age, tire4Pressure, tire4Age);

            Car car = new Car(model, engine, cargo, tires);

            carsInfo.add(car);
        }

        String task = scanner.nextLine();
        if (task.equals("fragile")) {
            // Cargo Type is "fragile" with a tire whose pressure is <1
            for (Car car : carsInfo) {
                if (car.getCargo().getCargoType().equals("fragile")) {
                    if (car.getTires().getTire1Pressure() < 1 ||
                            car.getTires().getTire2Pressure() < 1 ||
                            car.getTires().getTire3Pressure() < 1 ||
                            car.getTires().getTire4Pressure() < 1) {
                        System.out.println(car.getModel());
                    }
                }
            }
        } else if (task.equals("flamable")) {
            // Cargo Type is "flamable" and have Engine Power > 250
            for (Car car : carsInfo) {
                if (car.getCargo().getCargoType().equals("flamable")) {
                    if (car.getEngine().getEnginePower()>250) {
                        System.out.println(car.getModel());
                    }
                }
            }
        }
    }
}
