package DefiningClasses7;

import java.util.ArrayList;
import java.util.List;

public class Person {

    private Company company;
    private Car car;

    private List<Parent> parents;
    private List<Child> children;
    private List<Pokemon> pokemons;

    public Person() {
        this.parents = new ArrayList<>();
        this.pokemons = new ArrayList<>();
        this.children = new ArrayList<>();
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public List<Pokemon> getPokemons() {
        return pokemons;
    }

    public List<Parent> getParents() {
        return parents;
    }

    public List<Child> getChildren() {
        return children;
    }

    public Company getCompany() {
        return company;
    }

    public Car getCar() {
        return car;
    }

    @Override
    public String toString() {
        StringBuilder toPrint = new StringBuilder();

        toPrint.append("Company:" + "\n");
        if (company != null) {
            toPrint.append(company.toString() + "\n");
        }

        toPrint.append("Car:" + "\n");
        if (car !=null) {
            toPrint.append(car.toString() + "\n");
        }


        toPrint.append("Pokemon:" + "\n");
        if (pokemons.size() == 0) {
            toPrint.append("");
        } else {
            for (Pokemon pokemon : pokemons) {
                toPrint.append((pokemon.toString() + "\n"));
            }
        }

        toPrint.append("Parents:" + "\n");
        if (parents.size() == 0) {
            toPrint.append("");
        } else {
            for (Parent parent : parents) {
                toPrint.append(parent.toString() + "\n");
            }
        }
        toPrint.append("Children:" + "\n");
        if (children.size() == 0) {
            toPrint.append("");
        } else {
            for (Child child : children) {
                toPrint.append(child.toString() + "\n");
            }
        }
        return toPrint.toString();
    }
}
