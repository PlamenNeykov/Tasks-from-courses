package DefiningClasses7;

import java.util.HashMap;
import java.util.Locale;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        HashMap<String,Person> personalData = new HashMap<>();

        String input = scanner.nextLine();

        while (!input.equals("End")){
            String[] inputs = input.split("\\s+");
            String name = inputs[0];
            if(!personalData.containsKey(name)) {
                personalData.put(name,new Person());
            }
            String className = inputs[1];

            switch (className) {
                case "company":
                    String companyName = inputs[2];
                    String department = inputs[3];
                    double salary = Double.parseDouble(inputs[4]);
                    Company company = new Company(companyName,department,salary);
                    personalData.get(name).setCompany(company);
                    break;
                case "pokemon":
                    String pokemonName = inputs[2];
                    String pokemonType = inputs[3];
                    Pokemon pokemon = new Pokemon(pokemonName,pokemonType);
                    personalData.get(name).getPokemons().add(pokemon);
                    break;
                case"parents":
                    String parentName = inputs[2];
                    String parentBirthday = inputs[3];
                    Parent parent = new Parent(parentName,parentBirthday);
                    personalData.get(name).getParents().add(parent);
                        break;
                case "children":
                    String childName = inputs[2];
                    String childBirtdday = inputs[3];
                    Child child = new Child(childName,childBirtdday);
                    personalData.get(name).getChildren().add(child);
                    break;
                case "car":
                    String carModel = inputs[2];
                    int carSpeed = Integer.parseInt(inputs[3]);
                    Car car = new Car(carModel,carSpeed);
                    personalData.get(name).setCar(car);
                        break;
            }
            input = scanner.nextLine();
        }
        String controlledPerson = scanner.nextLine();

        System.out.println(controlledPerson);

        Person personalInfo = personalData.get(controlledPerson);


        System.out.println(personalInfo);

        // 3:08
    }
}
