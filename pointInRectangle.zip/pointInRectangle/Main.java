package A_WorkingWithAbstraction.pointInRectangle;

import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] coordinatesOfRectangle = Arrays.stream(scanner.nextLine().split(" "))
                .mapToInt(Integer::parseInt)
                .toArray();

        int downX = coordinatesOfRectangle[0];
        int downY = coordinatesOfRectangle[1];
        Point down = new Point(downX,downY);

        int upX = coordinatesOfRectangle[2];
        int upY = coordinatesOfRectangle[3];
        Point up = new Point(upX,upY);

        Rectangle rectangle = new Rectangle(down,up);

        int countToCheck = Integer.parseInt(scanner.nextLine());

        for (int i = 0; i < countToCheck; i++) {
            int[] coordinatesToCheck = Arrays.stream(scanner.nextLine().split(" "))
                    .mapToInt(Integer::parseInt)
                    .toArray();

            Point pointForCheck = new Point(coordinatesToCheck[0],coordinatesToCheck[1]);
            System.out.println(rectangle.contains(pointForCheck));
        }



    }
}
