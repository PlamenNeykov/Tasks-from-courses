package A_WorkingWithAbstraction.pointInRectangle;

public class Rectangle {
    private Point downLeft;
    private Point upRight;

    public Rectangle(Point downLeft, Point upRight) {
        this.downLeft = downLeft;
        this.upRight = upRight;
    }

    public boolean contains (Point point) {
        boolean checkX = point.getX()>=downLeft.getX()&&point.getX()<= upRight.getX();
        boolean checkY = point.getY()>=downLeft.getY()&&point.getY()<= upRight.getY();

        return checkX&&checkY;
    }

}
